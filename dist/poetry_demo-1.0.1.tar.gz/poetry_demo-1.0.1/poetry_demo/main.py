def start():
    print("this is a test")